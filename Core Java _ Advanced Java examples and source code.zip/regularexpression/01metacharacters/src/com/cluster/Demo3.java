package com.cluster;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class Demo3 {
	public static void main(String[] args) {
			//Matches a single numeric digit (0 to 9)
	/*	Pattern p = Pattern.compile("\\d");
		Matcher m = p.matcher("5");
		boolean b = m.matches();
		System.out.println(b);
	*/
		
		//Matches any two numeric digit (0 to 9)
	/*	Pattern p = Pattern.compile("\\d\\d");
		Matcher m = p.matcher("28");
		boolean b = m.matches();
		System.out.println(b);
	*/
		
		//Matches any three numeric digit (0 to 9)
	/* 	Pattern p = Pattern.compile("\\d\\d\\d");
		Matcher m = p.matcher("214");
		boolean b = m.matches();
		System.out.println(b);
	*/
		
	}
}
