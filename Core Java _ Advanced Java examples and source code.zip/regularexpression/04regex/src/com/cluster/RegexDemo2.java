package com.cluster;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class RegexDemo2 {

	public static void main(String[] args) {

		// find() matches sub sequence
	/*	Pattern p = Pattern.compile("ab");
		Matcher m = p.matcher("abcdef");
		boolean b = m.find();
		System.out.println(b);
	*/
		
	/*	Pattern p = Pattern.compile("ab");
		Matcher m = p.matcher("abaaab");
		while (m.find()) {
			System.out.print(m.start() + " ");
		}
	*/	
	
	/*	Pattern p = Pattern.compile("aba");
		Matcher m = p.matcher("abababa");
		while (m.find()) {
			System.out.print(m.start() + " ");
		}
	 */	
	}
}
