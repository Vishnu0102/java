package com.cluster;

import java.util.TreeSet;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class Demo {

	public static void main(String[] args) {
		
		TreeSet set = new TreeSet();
		set.add("Ravi");
		set.add("Amar");

	//	set.add(new Integer(10));
	//	set.add(new Integer(5));
		System.out.println("value in set is " + set);

	}

}
