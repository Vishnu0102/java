package com.cluster;

import java.util.HashSet;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class HashSetConstructorDemo {
	public static void main(String[] args) {
		
		HashSet set = new HashSet(8,0.75f);

	}

}
