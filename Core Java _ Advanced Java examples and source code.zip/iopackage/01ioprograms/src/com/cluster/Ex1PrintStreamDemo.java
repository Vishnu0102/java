package com.cluster;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class Ex1PrintStreamDemo {

	public static void main(String[] args) {
		int i = 10;
		System.out.println(i);
		String s = "hello";
		System.out.println(s);
		double d = 10.99;
		System.out.println(d);
		System.out.println("Val of i is " + i);

	}

}
