package com.cluster;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class B implements A.Hello
{
	public void m1()
	{
		System.out.println("Inside B m1");
	}
}