package com.cluster;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class C
{
	void m3()
	{
		System.out.println("Inside C m3()");
	}
}
