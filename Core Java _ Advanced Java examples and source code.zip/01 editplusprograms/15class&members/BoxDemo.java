class Box
{
	int w;
	int h;
	int d;
}
class BoxDemo 
{
	public static void main(String[] args) 
	{
//		int z;
//		z = 6;
		int z = 6;

//		Box b ;
//		b = new Box();
Box b = new Box(); // declaring, creating an instance & initializing the reference variable

	
	/*	System.out.println("Hello World!");
		Box b; //declaring a reference variable
		b = new Box(); // creating an instance or object
		System.out.println("Value of b is" + b);
		System.out.println("Value of w in b is" + b.w);
		System.out.println("Value of h in b is" + b.h);
		System.out.println("Value of d in b is" + b.d);
		b.w = 1;
		b.h = 2;
		b.d = 3;
		System.out.println("Value of b is" + b);
		System.out.println("Value of w in b is" + b.w);
		System.out.println("Value of h in b is" + b.h);
		System.out.println("Value of d in b is" + b.d);
		int vol = b.w * b.h * b.d;
		System.out.println("Volume of box b is" + vol);


		Box b1; //declaring a reference variable
		b1 = new Box(); // creating an instance or object
		System.out.println("Value of b is" + b1);
		System.out.println("Value of w in b1 is" + b1.w);
		System.out.println("Value of h in b1 is" + b1.h);
		System.out.println("Value of d in b1 is" + b1.d);
		b1.w = 4;
		b1.h = 5;
		b1.d = 6;
		System.out.println("Value of b1 is" + b1);
		System.out.println("Value of w in b1 is" + b1.w);
		System.out.println("Value of h in b1 is" + b1.h);
		System.out.println("Value of d in b1 is" + b1.d);
		vol = b1.w * b1.h * b1.d;
		System.out.println("Volume of box b1 is" + vol); */

	}
}
