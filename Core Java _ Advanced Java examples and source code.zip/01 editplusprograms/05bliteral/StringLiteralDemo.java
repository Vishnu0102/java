class StringLiteralDemo 
{
	public static void main(String[] args) 
	{
		
//		char x = 'A';

//		System.out.println("Value of x is " + x);

	//	String s1 = "\"Hello World\'";

	//	System.out.println("Value of s1 is " + s1);

	System.out.print("\"Hello\tWorld\'\n");
	System.out.println("Welcome");

	}
}
