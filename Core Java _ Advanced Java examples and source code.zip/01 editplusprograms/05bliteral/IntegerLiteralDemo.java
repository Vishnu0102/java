class IntegerLiteralDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
/*		int i = 296; // Decimal integer literal
		System.out.println("value of i is" +i ); */

/*			long i = 0123; // Octal integer literal
		System.out.println("value of i is" +i ); */

			long i = 0x523ead; // Octal integer literal
		System.out.println("value of i is" +i );
	}
}
