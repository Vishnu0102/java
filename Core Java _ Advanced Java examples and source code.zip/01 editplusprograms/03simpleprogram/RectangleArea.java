class RectangleArea
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		int l = 10;
		int b = 5;
		int a = 0;
		a = l * b;
		System.out.println("Length of rectangle is " + l);
		System.out.println("Breadth of rectangle is " + b);
		System.out.println("Area of rectangle is " + a);
		System.out.println("I've finished my assign " + "Length of rectangle is " + l  + "My name is Ravi");

	}
}
