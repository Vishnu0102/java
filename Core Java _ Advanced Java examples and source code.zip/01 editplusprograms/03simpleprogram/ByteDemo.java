class ByteDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		byte b = 0;
		System.out.println("Value of b is" + b);
		byte b = 7;
		System.out.println("Value of b is" + b);
	/*	b = (byte)-129;
		System.out.println("Value of b is" + b);  */

/*		byte x = 5;
		int y = 0;
		y = x;
		System.out.println("Value of x is" + x);
		System.out.println("Value of y is" + y); */

	/*	int x = 260;
		byte y = 0;
		y = (byte)x;
		System.out.println("Value of x is" + x);
		System.out.println("Value of y is" + y);  */





	}
}
