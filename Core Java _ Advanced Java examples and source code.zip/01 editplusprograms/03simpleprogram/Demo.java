class  Demo
{
	public static void main(String[] args) 
	{
	//	System.out.println("Hello World!");
	/*	int a = 10;
		int b = 20;
		int c = a + b;
		System.out.println("Value of a is " + a);
		System.out.println("Value of b is " + b);
		System.out.println("Value of c is " + c); */

		for (int i = 0;i < 5 ; i++ )
		{
			System.out.println("Value of  i is" + i );
		}

		int z = 5;
		if ( z >3)
		{
			System.out.println("z is greater than 3" );
		}
		else
		{
			System.out.println("z is lesser than 3" );
		}



	}
}
