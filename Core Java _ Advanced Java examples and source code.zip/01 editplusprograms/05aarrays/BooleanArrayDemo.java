class BooleanArrayDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");

	/*	int []x = {100,101,102,103,104};
		System.out.println("Length of the array is" + x.length);*/
		char x[] = new char[5];
		x[0]= 'A';



		for (int i = 0;i < x.length ; i++)
		{
			System.out.println("Value in "+ i +" index is" + x[i]);

		}

	}
}
