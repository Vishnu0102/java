class ArithmeticOperatorDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		int a = 10;
		int b = 20;
		int c = a + b;
//		System.out.println("Value of a is "  + a);
//		System.out.println("Value of b is "  + b);
//		System.out.println("Value of c is "  + c);
//		System.out.println("Value of a,b,c is "  + a + b +c);
//	System.out.println("A"+ a + b +c); 

		String s1 = "hello";
		String s2 = "20";
		String s3 = s1 + s2;

		int x = Integer.parseInt(s2);

		System.out.println("Value of x is "  + x);

		System.out.println("Value of s1 is "  + s1);
		System.out.println("Value of s2 is "  + s2);
		System.out.println("Value of s3 is "  + s3);

		
	/*	int y = Integer.parseInt(s2);
		int z = x + y;

		System.out.println("Value of x is "  + x);
		System.out.println("Value of y is "  + y);
		System.out.println("Value of z is "  + z);

		System.out.println("Value of s1 is "  + s1);
		System.out.println("Value of s2 is "  + s2);
		System.out.println("Value of s3 is "  + s3); */

/*		int a = 5;
		int b = -a;
		System.out.println("Value of a is" + a);

		System.out.println("Value of b is " +b);*/



	}
}
