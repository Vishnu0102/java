class DoWhileDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		int n = -5; // initialization
		do
		{
			System.out.println("Value of n is " + n);
			n--;	// increment or decrement operation
		}while (n>0); // condition

		System.out.println("End of do while!");
	}
}
