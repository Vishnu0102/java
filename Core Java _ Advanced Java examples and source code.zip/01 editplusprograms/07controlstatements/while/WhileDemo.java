class WhileDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");

		int n = 5; //initialization
		while (n>0) // condition
		{
			System.out.println("Value of n is " + n);
			n--; // increment or decrement operation
		}

		System.out.println("End of  while!");
	}
}
