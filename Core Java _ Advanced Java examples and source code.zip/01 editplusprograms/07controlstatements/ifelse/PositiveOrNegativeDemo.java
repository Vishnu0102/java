// program to find positive or negative number

class PositiveOrNegativeDemo
{
	public static void main(String[] args) 
	{
		
		int a = Integer.parseInt(args[0]);
		if (a>0)
		{
			System.out.println("positive number");
		}
		else
		{
			System.out.println("negative number");
		}

	}
} 
