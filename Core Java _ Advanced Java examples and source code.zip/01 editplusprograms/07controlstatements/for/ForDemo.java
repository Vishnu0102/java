class ForDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("Begin of for loop");

		for (int i = 0; i < 5 ; i++ )
		{
			System.out.print("Inside  for loop"+ "\t");
			System.out.println("Value of i is " + i);

		}
		System.out.println("End of for loop");
	}
}
