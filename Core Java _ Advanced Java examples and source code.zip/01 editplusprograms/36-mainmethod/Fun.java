class Fun 
{
	 static 
	{
		System.out.println("Hello World!");
	}
}
