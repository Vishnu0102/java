class Hello 
{
	public static void main(String[] args) 
	{
		System.out.println("Inside super class");
	}
}

class Hello1 extends Hello 
{
	public static void main(String[] args) 
	{
		System.out.println("Inside sub class");
	}
}
