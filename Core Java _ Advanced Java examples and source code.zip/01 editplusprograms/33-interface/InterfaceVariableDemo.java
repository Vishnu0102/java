interface A
{
	int x = 5;
	void m1();
	
};























/*class B implements A
{
	public void m1()
	{
		System.out.println("Inside m1");
		System.out.println("Value of x is " + x);
		System.out.println("Value of y is " + y);
	}
	public void m2()
	{
		System.out.println("Inside m2");
		System.out.println("Value of x is " + x);
		System.out.println("Value of y is " + y);
	}
};


class InterfaceVariableDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	//	System.out.println("Value of x is " + A.x);
	//	System.out.println("Value of y is " + A.y);
		A a = null;
	//	System.out.println("Value of x is " + a.x);
	//	System.out.println("Value of y is " + a.y);
		B b = new B();
//		System.out.println("Value of x with b is " + B.x);
//		System.out.println("Value of y with b is " + B.y);
		b.m1();
		b.m2();
	/*	a.x = 99;
		a.y = 88;
		b.x = 77;
		b.y = 66;


	}
}*/
