class Hello 
{
	static 
	{
		System.out.println("Hello World!");
	}
}
