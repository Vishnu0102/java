package p1;

class Box 
{
	
	int w = 10;
	int h = 20;
	int d = 30;


	void m1()
	{
		System.out.println("inside m1");
	}
}
