package p1;

class Demo 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World !");
		Box b = new Box();
		System.out.println("Val of w in b is!" + b.w);
		System.out.println("Val of h in b is!" + b.h);
		System.out.println("Val of d in b is!" + b.d);
		b.m1();

	}
}