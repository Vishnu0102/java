class Add
{
	public static void main(String args[])
	{
//		System.out.println("Hellooooo");
		int a = 10;
		int b = 5;
		int c = 0;
		System.out.println("Value of a is " + a);
		System.out.println("Value of b is " + b);
		System.out.println(c);
		c = a + b;

		String s1 = "Ravi";

		String s2 = s1 + a; 
		System.out.println(s2);

	//	String s2 = "Cluster";

	//	String s3 = s1 + s2;
	//	System.out.println(s1);
	//	System.out.println(s2);
	//	System.out.println(s3);

//		System.out.println(s1 + " \t" + s2 );

	//	System.out.println(s2);

	}

}