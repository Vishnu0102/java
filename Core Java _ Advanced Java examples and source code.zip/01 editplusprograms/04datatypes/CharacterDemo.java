class CharacterDemo 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		char x = 'A';
		
		System.out.println(x);
		x++;
		System.out.println(x);
	}
}
