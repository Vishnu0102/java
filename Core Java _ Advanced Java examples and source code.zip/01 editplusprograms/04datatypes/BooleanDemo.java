class BooleanDemo 
{
	public static void main(String[] args) 
	{
	//	System.out.println("Hello World!");
		boolean b = 10;
	//	System.out.println("Value of b is " + b);
	//	boolean b = true;
	//	System.out.println("Value of b is " + b);

	/*	if (b)
		{
			System.out.println("Welcome");
		}
		else
		{
			System.out.println("Not Welcome");
		} */

	/*	int i = 10;
		int j = 9;

		boolean b = i > j;
		System.out.println("Value of b is " + b); */
	}
}
