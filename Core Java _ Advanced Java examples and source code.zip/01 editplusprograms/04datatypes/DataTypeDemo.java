class DataTypeDemo 
{
	public static void main(String[] args) 
	{
	/*	System.out.println("Hello World!");
		byte b = (byte)512; // Explicit casting
		System.out.println("Value of b is " + b); */
	/*	long l = 12L;
		System.out.println("Value of l is " + l); */

		// Floating values
		// single precision value
		float f  = 12.2f;
//		float f = (float)12.679;
		System.out.println("Value of f is " + f);


		// double precision values with standard notation
	//	double d = 75000.0;
	//	System.out.println("Value of d is " + d);

		// double precision values with scientific notation

	//	double d = -75e3;
	//	double d = -7.5e4;
	//	double d = -.75e5;
	//	double d = -0.75e5;

	//	System.out.println("Value of d is " + d);

// double precsion fractional value satandard notation
//	double d = 0.000075;
//	System.out.println("Value of d is " + d);

	// double precsion fractional value scientific notation
//	double d = 7.5e-9;
//	System.out.println("Value of d is " + d);

	}
}
