class AutoPromotionDemo 
{
	public static void main(String[] args) 
	{
	/*	byte a = 100;
		byte b = 50;
		byte c = 0;

		System.out.println("value of a is " + a);
		System.out.println("value of b is " + b);
		System.out.println("value of c is " + c);

		//c = a + b;
		c = (byte)(a+b);
		System.out.println("value of c is " + c);

		int z = a + b;

		System.out.println("value of z  is " + z); */

	/*	short s = 10;
		byte b = 5;

		byte  z = (byte)(s + b);
		System.out.println("value of z  is " + z); */

	/*	int a = 4;
		long b = 3;

		double z = a*b;
		System.out.println("value of z  is " + z); */

		byte b = 1;
		short s = 2;
		int i = 3;
		long l = 4;
		float f = 5.0f;
		double d = 6.0;

		double z = d*i/s-(b+f)*l;
		System.out.println("value of z  is " + z);





	}
}
