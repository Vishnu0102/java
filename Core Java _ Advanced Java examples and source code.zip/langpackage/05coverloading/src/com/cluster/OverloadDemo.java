package com.cluster;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class OverloadDemo {

	public static void main(String[] args) {
		Hello h = new Hello();
		int a = 10;
		int b = 20;
		h.m1(a, b);
		//byte z = a;

	}

}
