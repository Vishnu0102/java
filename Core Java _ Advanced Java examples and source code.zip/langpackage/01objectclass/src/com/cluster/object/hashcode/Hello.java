package com.cluster.object.hashcode;


/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class Hello {
	int a;
	int b;
	
	public Hello(int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	public int hashCode(){
		return 88;
	}

}
