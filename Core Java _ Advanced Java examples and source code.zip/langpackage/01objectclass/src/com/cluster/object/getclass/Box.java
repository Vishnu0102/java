package com.cluster.object.getclass;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class Box {
	int w;
	int h;
	int d;
	public Box(int w, int h, int d) {
		this.w = w;
		this.h = h;
		this.d = d;
	}
}
