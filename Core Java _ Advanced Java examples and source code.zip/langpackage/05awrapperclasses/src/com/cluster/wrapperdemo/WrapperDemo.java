package com.cluster.wrapperdemo;


/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class WrapperDemo {
	public static void main(String[] args) {
		
		System.out.println("Max val of integer " + Integer.MAX_VALUE);
		System.out.println("Min val of integer " + Integer.MIN_VALUE);
		System.out.println("Size of integer " + Integer.SIZE);
		
	/*	int i = 1000;
		int j = 200;
		System.out.println("Val of i is " + i);
		System.out.println("Val of j is " + j);
		
		Integer x = new Integer(i); // Boxing
		Integer y = new Integer(j); // Boxing
		System.out.println("Val of x is " + x);
		System.out.println("Val of y is " + y);
		
		
		
		int z = x.compareTo(y);
		System.out.println("Val of z is " + z);
		*/
		
		/*int p  = x.intValue();
		System.out.println("Value of p is" + p); // Unboxing
*/
	}

}
