package com.cluster.boxing;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class Hello {
	void m1(Integer x)
	{
		System.out.println("inside Integer m1()");
	}
	
	void m1(char x)
	{
		
		System.out.println("inside primitive int  m1()");
	}

}
