package com.cluster.boxing;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class BoxingDemo {

	public static void main(String[] args) {
		
		Integer x = 10;
		Integer y = 20;
		Integer z = x + y;
		System.out.println("Val of z is " + z);
		
		/*int i = 10;
		Integer x = new Integer(i); // explicit boxing
		Integer y = 100; // implicit boxing
		System.out.println("Val of x is " + x);
		System.out.println("Val of y is " + y);
		*/
		/*x++;
		System.out.println(x);
*/		
		
	}

}
