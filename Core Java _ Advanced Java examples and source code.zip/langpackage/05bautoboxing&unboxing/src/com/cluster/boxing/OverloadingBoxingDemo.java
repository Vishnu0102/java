package com.cluster.boxing;


/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class OverloadingBoxingDemo {

	public static void main(String[] args) {
		Hello h = new Hello();
		int i = 10;
		h.m1(10);

	}

}
