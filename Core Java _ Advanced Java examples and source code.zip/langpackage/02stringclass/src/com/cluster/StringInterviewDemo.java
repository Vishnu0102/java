package com.cluster;


/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class StringInterviewDemo {
	public static void main(String[] args) {
		
		Object e1 = "Hello";
		System.out.println(e1);
		
		String s1 = "10";
		String s2 = "20";
		int i = 99;
		
		//String s3 = s1+s2;
		//System.out.println(s3);
		
		String s4 = s1 + i;
		System.out.println(s4);

	}

}
