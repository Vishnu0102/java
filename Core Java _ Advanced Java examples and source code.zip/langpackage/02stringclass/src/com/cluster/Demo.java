package com.cluster;


/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class Demo {

	public static void main(String[] args) {
		
	/*	String s1 = new String("hello");
		//System.out.println(s1);
		System.out.println(s1.toString());*/
		
		String s2 = "Hai";
		System.out.println(s2); // toString is invoked implicitly
		System.out.println(s2.toString());
		
		
		

	}

}
