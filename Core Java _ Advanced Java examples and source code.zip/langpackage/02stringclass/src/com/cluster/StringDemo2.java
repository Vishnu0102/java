package com.cluster;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class StringDemo2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1 = new String("Hello");
		String s2 = new String("Hello");
		String s3 ="Hello";
		
		String s4 = "Hai";
		String s5 = "Hai";
		
		s1 = "cluster";
		s4 = "World";
		s5 = "Welcome";
	}
}
