package com.cluster;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class SystemDemo {
	public static void main(String[] args) {
		
		/*System.out.println("Hello World!");
		System.out.println(System.getProperty("os.name"));
		System.out.println(System.getProperty("user.name"));
		System.out.println(System.getProperty("java.version"));
		System.out.println(System.getenv("Path"));
		System.out.println(System.getenv("JAVA_HOME"));
		*/
		
		System.out.println("Begin main");
		System.exit(0);
		System.out.println("End of main");

	}

}
