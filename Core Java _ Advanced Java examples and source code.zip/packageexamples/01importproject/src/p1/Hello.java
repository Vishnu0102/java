package p1;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class Hello {
	public int p = 10;
	public int q = 20;
	
	public Hello()
	{}
	
	public void fun()
	{
		System.out.println("Inside fun");
	}
	
}
