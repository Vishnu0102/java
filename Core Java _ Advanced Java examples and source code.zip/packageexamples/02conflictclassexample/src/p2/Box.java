package p2;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class Box {
	
	public int p = 10;
	public int q = 20;
	
	public void fun()
	{
		System.out.println("Inside fun");
	}

}
