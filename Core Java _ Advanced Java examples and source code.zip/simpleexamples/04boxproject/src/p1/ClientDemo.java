package p1;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class ClientDemo {
	public static void main(String[] args) {
/*		Box box = new Box(1, 2, 3);
		System.out.println("val of width is " + box.width);
		System.out.println("val of height is " + box.height);
		System.out.println("val of depth is " + box.depth);
		int v = box.volume();
		System.out.println("Volume of box is " + v);
		box.m1();
*/		
		
		Shipment shipment = new Shipment(1, 2, 3, 4, 5);
		
	}

}
