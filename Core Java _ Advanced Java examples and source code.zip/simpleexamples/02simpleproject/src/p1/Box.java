package p1;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class Box {
	int width = 10;
	int heigth= 300;
	int depth = 30;
	
	void printSomething()
	{
		System.out.println("Inside printsomething");
	}

}
