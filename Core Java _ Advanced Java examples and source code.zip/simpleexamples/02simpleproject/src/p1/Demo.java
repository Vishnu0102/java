package p1;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class Demo {
	public static void main(String[] args) {
		System.out.println("Hello world");
		Box b = new Box();
		System.out.println("Val of width is "+ b.width);
		System.out.println("Val of height is "+ b.heigth);
		System.out.println("Val of depth is "+ b.depth);
		b.printSomething();

	}

}
