package com.cluster;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
class X
{
	void m1() throws IOException
	{
		
	}
}

/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
class Y extends X
{
	void m1() throws FileNotFoundException
	{
		
	}
	
}


/**
 *  Cluster Software Solutions.
 *  (Mob:98451-31637/39
 *  www.clusterindia.com)
 */
public class InterviewQuestionsDemo 
{
	public static void main(String[] args) throws Exception
	{
		try 
		{
		System.out.println("Begin main");
		//return;
		//throw new Exception();
		System.exit(0);
		}

		finally
		{
		System.out.println("End main");
		}

	}

}
